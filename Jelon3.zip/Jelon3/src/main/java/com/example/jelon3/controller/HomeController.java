package com.example.jelon3.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "✅ Bienvenue, vous êtes connecté avec succès 🎉";
    }
}
