package com.example.jelon3.repository;

import com.example.jelon3.model.Projet;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProjetRepository extends JpaRepository<Projet, Long> {
    List<Projet> findByUtilisateurId(Long utilisateurId);
}
