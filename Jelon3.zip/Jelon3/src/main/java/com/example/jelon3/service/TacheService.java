package com.example.jelon3.service;

import com.example.jelon3.model.Tache;
import com.example.jelon3.repository.TacheRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TacheService {

    @Autowired
    private TacheRepository tacheRepository;

    // 🔍 Récupère les tâches associées à un projet (par ID projet)
    public List<Tache> getTachesByProjet(Long projetId) {
        return tacheRepository.findByProjetId(projetId);
    }

    // 💾 Sauvegarde ou crée une tâche
    public Tache saveTache(Tache tache) {
        return tacheRepository.save(tache);
    }
}