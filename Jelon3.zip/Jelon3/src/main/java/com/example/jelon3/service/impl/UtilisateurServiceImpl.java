package com.example.jelon3.service.impl;

import com.example.jelon3.model.Utilisateur;
import com.example.jelon3.repository.UtilisateurRepository;
import com.example.jelon3.service.UtilisateurService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UtilisateurServiceImpl implements UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;

    public UtilisateurServiceImpl(UtilisateurRepository utilisateurRepository) {
        this.utilisateurRepository = utilisateurRepository;
    }

    @Override
    public Optional<Utilisateur> getUtilisateurParNom(String email) {
        return utilisateurRepository.findByEmail(email); // 🔄 modifié pour rechercher par email
    }

    @Override
    public Utilisateur enregistrer(Utilisateur utilisateur) {
        return utilisateurRepository.save(utilisateur);
    }
}
