package com.example.jelon3.controller;

import com.example.jelon3.model.Tache;
import com.example.jelon3.service.TacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/taches")
public class TacheController {

    @Autowired
    private TacheService tacheService;

    // 🔍 Récupère toutes les tâches liées à un projet (ID projet passé en URL)
    @GetMapping("/projet/{id}")
    public List<Tache> getTachesByProjet(@PathVariable Long id) {
        return tacheService.getTachesByProjet(id);
    }

    // 📥 Crée une tâche liée à un projet
    @PostMapping
    public Tache createTache(@RequestBody Tache tache) {
        return tacheService.saveTache(tache);
    }
}