package com.example.jelon3.service;

import com.example.jelon3.model.Projet;
import com.example.jelon3.repository.ProjetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjetService {

    @Autowired
    private ProjetRepository projetRepository;

    // 🔍 Récupère les projets d’un utilisateur (par son ID)
    public List<Projet> getProjetsByUtilisateur(Long utilisateurId) {
        return projetRepository.findByUtilisateurId(utilisateurId);
    }

    // 💾 Sauvegarde ou crée un nouveau projet
    public Projet saveProjet(Projet projet) {
        return projetRepository.save(projet);
    }
}