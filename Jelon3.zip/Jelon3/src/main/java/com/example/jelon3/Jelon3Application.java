package com.example.jelon3;

import com.example.jelon3.model.Utilisateur;
import com.example.jelon3.repository.UtilisateurRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com.example.jelon3.repository")
@EntityScan("com.example.jelon3.model")
public class Jelon3Application {

    public static void main(String[] args) {
        SpringApplication.run(Jelon3Application.class, args);
    }

    @Bean
    CommandLineRunner runner(UtilisateurRepository utilisateurRepository, PasswordEncoder encoder) {
        return args -> {

            // ✅ Créer l'utilisateur membre (zitoune)
            if (utilisateurRepository.findByEmail("zitoune@example.com").isEmpty()) {
                Utilisateur user = new Utilisateur();
                user.setNom("zitoune");
                user.setEmail("zitoune@example.com");
                user.setMotDePasse(encoder.encode("123456"));
                user.setRole("membre");
                utilisateurRepository.save(user);
                System.out.println("✅ Utilisateur 'zitoune@example.com' ajouté !");
            }

            // ✅ Créer le gestionnaire
            if (utilisateurRepository.findByEmail("gestionnaire@example.com").isEmpty()) {
                Utilisateur gestionnaire = new Utilisateur();
                gestionnaire.setNom("Gestionnaire Démo");
                gestionnaire.setEmail("gestionnaire@example.com");
                gestionnaire.setMotDePasse(encoder.encode("123456"));
                gestionnaire.setRole("gestionnaire");
                utilisateurRepository.save(gestionnaire);
                System.out.println("✅ Utilisateur 'gestionnaire@example.com' ajouté !");
            }
        };
    }
}
