package com.example.jelon3.controller;

import com.example.jelon3.dto.AuthRequest;
import com.example.jelon3.dto.AuthResponse;
import com.example.jelon3.model.Utilisateur;
import com.example.jelon3.repository.UtilisateurRepository;
import com.example.jelon3.security.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
        try {
            // 🔐 Authentifie l'utilisateur avec email et mot de passe
            authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getEmail(),
                            request.getPassword()
                    )
            );

            // 🔎 Récupère l'utilisateur depuis la base de données
            Utilisateur utilisateur = utilisateurRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

            // 🎫 Génère le token JWT avec l'email et le rôle
            String token = jwtService.generateToken(utilisateur.getEmail(), utilisateur.getRole(),utilisateur.getId());

            return ResponseEntity.ok(new AuthResponse(token));
        } catch (AuthenticationException e) {
            return ResponseEntity.status(401).body("Identifiants invalides");
        }
    }
}
