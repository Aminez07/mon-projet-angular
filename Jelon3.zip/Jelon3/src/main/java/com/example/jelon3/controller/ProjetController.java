package com.example.jelon3.controller;

import com.example.jelon3.model.Projet;
import com.example.jelon3.service.ProjetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projets")
public class ProjetController {

    @Autowired
    private ProjetService projetService;

    // 🔍 Récupère tous les projets d’un utilisateur spécifique (ID utilisateur passé en URL)
    @GetMapping("/utilisateur/{id}")
    public List<Projet> getProjetsByUtilisateur(@PathVariable Long id) {
        return projetService.getProjetsByUtilisateur(id);
    }

    // 📥 Crée un nouveau projet (avec utilisateur dans le JSON)
    @PostMapping
    public Projet createProjet(@RequestBody Projet projet) {
        return projetService.saveProjet(projet);
    }
}