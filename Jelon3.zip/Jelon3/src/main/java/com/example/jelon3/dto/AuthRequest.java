package com.example.jelon3.dto;

/**
 * DTO pour la requête d'authentification.
 * Utilisé dans /api/auth/login pour envoyer l'email et le mot de passe.
 */
public class AuthRequest {

    private String email;
    private String password;

    // Constructeur vide requis pour la désérialisation JSON
    public AuthRequest() {}

    public AuthRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Getters et Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
