package com.example.jelon3.service;

import com.example.jelon3.model.Utilisateur;
import java.util.Optional;

public interface UtilisateurService {
    Optional<Utilisateur> getUtilisateurParNom(String email); // 🔄 changé de "nom" vers "email"
    Utilisateur enregistrer(Utilisateur utilisateur);
}
