package com.example.jelon3.controller;

import com.example.jelon3.model.Utilisateur;
import com.example.jelon3.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/utilisateurs")
public class UtilisateurController {

    private final UtilisateurService utilisateurService;

    @Autowired
    public UtilisateurController(UtilisateurService utilisateurService) {
        this.utilisateurService = utilisateurService;
    }

    @GetMapping("/{email}")
    public Optional<Utilisateur> getUtilisateur(@PathVariable String email) {
        return utilisateurService.getUtilisateurParNom(email); // ✅ email au lieu de nom
    }

    @PostMapping
    public Utilisateur ajouterUtilisateur(@RequestBody Utilisateur utilisateur) {
        return utilisateurService.enregistrer(utilisateur);
    }
}
