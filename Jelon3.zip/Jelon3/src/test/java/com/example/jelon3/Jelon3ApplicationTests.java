package com.example.jelon3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jelon3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
